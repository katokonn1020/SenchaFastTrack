Ext.define('YelpExtplorer.view.main.BaseController', {
    extend: 'Ext.app.ViewController',
    requires: [
        'YelpExtplorer.util.Geocode',
    ],
    geocodeCity: function (city) {
        var me = this;
        YelpExtplorer.util.Geocode.geocodeAddress(city, function (coordinates) {
            if (coordinates) {
                me.getViewModel().set('location', coordinates);
            }
        });
    },
    initViewModel: function (vm) {
        var me = this;

        vm.bind('{city}', Ext.Function.createBuffered(me.geocodeCity, 1000), me);

    }
});

