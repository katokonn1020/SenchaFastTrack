Ext.define('YelpExtplorer.view.Banner', { 
    extend: 'Ext.panel.Panel',
    xtype: 'banner',
    height: 36,
    html: '<img src="resources/images/YelpExtplorerLogo.png" />'
});