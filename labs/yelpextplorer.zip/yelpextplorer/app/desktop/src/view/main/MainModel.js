Ext.define('YelpExtplorer.view.main.MainModel', {
    extend: 'YelpExtplorer.view.main.BaseModel',
    alias: 'viewmodel.main-main',
    data: {
        name: 'YelpExtplorer'
    }

});
