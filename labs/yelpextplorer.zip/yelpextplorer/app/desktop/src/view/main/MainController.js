Ext.define('YelpExtplorer.view.main.MainController', {
    extend: 'YelpExtplorer.view.main.BaseController',
    alias: 'controller.main-main'

});
