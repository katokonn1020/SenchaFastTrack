Ext.application({
    name: 'Beatles',
    extend: 'Beatles.Application',
    requires: ['Beatles.view.main.Main'],
    mainView: 'Beatles.view.main.Main'
});