Ext.define('Beatles.view.main.MainModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.main'
});